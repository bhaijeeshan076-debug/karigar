package com.autosilentzone

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File

/** Azan bajata hai (aapki chuni hui audio file se). Notification mein "Stop" button hai. */
class AzanService : Service() {
    private var player: MediaPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val label = intent?.getStringExtra("label") ?: "Azan"
        val file = fileFor(this, intent?.getStringExtra("key") ?: "")

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("azan", "Azan", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, AzanService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, "azan")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle("Azan: $label").setOngoing(true)
            .addAction(0, "Stop", stop).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(77, n)

        if (file == null) { stopSelf(); return START_NOT_STICKY }
        try {
            player?.release()
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                setDataSource(file.absolutePath)
                setOnCompletionListener { stopSelf() }
                prepare()
                start()
            }
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        player?.release(); player = null
        super.onDestroy()
    }

    companion object {
        /** Fajr ke liye alag file ho to wo, warna sabke liye wali file. */
        fun fileFor(ctx: Context, key: String): File? {
            val main = File(ctx.filesDir, "azan.mp3")
            val fajr = File(ctx.filesDir, "fajr_azan.mp3")
            return if (key == "fajr" && fajr.exists()) fajr else if (main.exists()) main else if (fajr.exists()) fajr else null
        }
    }
}
