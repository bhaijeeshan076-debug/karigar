package com.autosilentzone

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import java.io.File
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class PrayerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLang.load(this)
        setContent { MaterialTheme { Screen() } }
    }

    private fun copyAudio(uri: Uri, name: String): Boolean = try {
        contentResolver.openInputStream(uri)?.use { input -> File(filesDir, name).outputStream().use { input.copyTo(it) } }
        true
    } catch (e: Exception) { false }

    @Composable
    fun Screen() {
        val s = remember { Store(this) }
        var loc by remember { mutableStateOf(if (s.hasLocation) s.lat to s.lng else null) }
        var method by remember { mutableStateOf(s.method) }
        var asr by remember { mutableStateOf(s.asr) }
        var lead by remember { mutableStateOf(s.prayerLead) }
        var on by remember { mutableStateOf(s.prayerOn) }
        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        val fmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
        var azanOn by remember { mutableStateOf(s.azanOn) }
        var azanTick by remember { mutableStateOf(0) }
        val hasAzan = remember(azanTick) { File(filesDir, "azan.mp3").exists() || File(filesDir, "fajr_azan.mp3").exists() }
        val pickAzan = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null && copyAudio(uri, "azan.mp3")) { azanTick++; PrayerReminders.scheduleAll(this@PrayerActivity) }
        }
        val pickFajr = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null && copyAudio(uri, "fajr_azan.mp3")) { azanTick++; PrayerReminders.scheduleAll(this@PrayerActivity) }
        }

        LaunchedEffect(Unit) {
            try {
                LocationServices.getFusedLocationProviderClient(this@PrayerActivity).lastLocation.addOnSuccessListener {
                    if (it != null) {
                        s.lat = it.latitude; s.lng = it.longitude
                        loc = it.latitude to it.longitude
                        PrayerReminders.scheduleAll(this@PrayerActivity)
                    }
                }
            } catch (_: SecurityException) {}
        }

        val times = remember(loc, method, asr) {
            loc?.let { PrayerTimes.compute(Calendar.getInstance(), it.first, it.second, method, asr) }
        }
        val next = remember(loc, method, asr) { loc?.let { PrayerTimes.next(it.first, it.second, method, asr) } }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tr("Prayer times","नमाज़ के वक़्त","Namaz ke waqt"), style = MaterialTheme.typography.headlineSmall)

            if (times == null) {
                Text(tr("Location not found. Allow location in Setup, turn on GPS and reopen.","लोकेशन नहीं मिली। सेटअप में अनुमति दें, GPS चालू करें और फिर खोलें।","Location nahi mili. Setup mein location permission do aur GPS on karke dobara kholo."))
            } else {
                if (next != null) {
                    val mins = ((next.time - System.currentTimeMillis()) / 60000).toInt()
                    Text("Agli namaz: ${next.label} (${fmt.format(Date(next.time))}) \u00B7 ${mins / 60} ghante ${mins % 60} min mein",
                        style = MaterialTheme.typography.titleMedium)
                }
                Text(tr("Turn on a switch for reminders","रिमाइंडर के लिए स्विच चालू करें","Reminder ke liye switch on karo"), style = MaterialTheme.typography.labelMedium)
                times.forEach { p ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(p.label, Modifier.weight(1f), fontWeight = if (p.key == next?.key) FontWeight.Bold else FontWeight.Normal)
                        Text(if (p.time > 0) fmt.format(Date(p.time)) else "--")
                        if (p.key != "sunrise") {
                            Switch(
                                checked = p.key in on, modifier = Modifier.padding(start = 12.dp),
                                onCheckedChange = { v ->
                                    on = if (v) on + p.key else on - p.key
                                    s.prayerOn = on
                                    if (v && Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    PrayerReminders.scheduleAll(this@PrayerActivity)
                                }
                            )
                        } else Spacer(Modifier.width(64.dp))
                    }
                }

                Text(tr("Azan", "अज़ान", "Azan"), style = MaterialTheme.typography.titleMedium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        tr("Play azan (for prayers with switch on)", "अज़ान बजाएँ (जिस नमाज़ का स्विच चालू है)", "Azan bajao (jis namaz ka switch on hai)"),
                        Modifier.weight(1f)
                    )
                    Switch(checked = azanOn, onCheckedChange = { azanOn = it; s.azanOn = it; PrayerReminders.scheduleAll(this@PrayerActivity) })
                }
                Text(
                    if (hasAzan) tr("Azan file selected", "अज़ान फ़ाइल चुनी गई है", "Azan file chuni hui hai")
                    else tr("No azan file yet. Pick one from your phone.", "अभी अज़ान फ़ाइल नहीं है। फ़ोन से चुनें।", "Azan file abhi nahi chuni. Phone se chuno."),
                    style = MaterialTheme.typography.bodySmall
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickAzan.launch(arrayOf("audio/*")) }) { Text(tr("Pick azan file", "अज़ान फ़ाइल चुनें", "Azan file chuno")) }
                    OutlinedButton(onClick = { pickFajr.launch(arrayOf("audio/*")) }) { Text(tr("Fajr azan (optional)", "फ़ज्र की अज़ान (वैकल्पिक)", "Fajr azan (optional)")) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = hasAzan, onClick = {
                        try {
                            ContextCompat.startForegroundService(
                                this@PrayerActivity,
                                Intent(this@PrayerActivity, AzanService::class.java).putExtra("label", "Test").putExtra("key", "dhuhr")
                            )
                        } catch (_: Exception) {}
                    }) { Text(tr("Test azan now", "अभी अज़ान टेस्ट करें", "Azan abhi test karo")) }
                    OutlinedButton(onClick = {
                        startService(Intent(this@PrayerActivity, AzanService::class.java).setAction("STOP"))
                    }) { Text(tr("Stop", "रोकें", "Rok do")) }
                }
                Text(
                    tr("Azan is not played inside a silent zone (mosque), you only get a notification.",
                        "साइलेंट ज़ोन (मस्जिद) के अंदर अज़ान नहीं बजती, सिर्फ़ नोटिफ़िकेशन आता है।",
                        "Silent zone (masjid) ke andar azan nahi bajta, sirf notification aata hai."),
                    style = MaterialTheme.typography.bodySmall
                )

                Text(tr("Calculation method","हिसाब का तरीका","Hisaab ka tareeka"), style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrayerTimes.methodNames.forEachIndexed { i, n ->
                        FilterChip(selected = method == i, onClick = { method = i; s.method = i; PrayerReminders.scheduleAll(this@PrayerActivity) }, label = { Text(n) })
                    }
                }
                Text(tr("Asr","अस्र","Asr"), style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = asr == 2, onClick = { asr = 2; s.asr = 2; PrayerReminders.scheduleAll(this@PrayerActivity) }, label = { Text(tr("Hanafi","हनफ़ी","Hanafi")) })
                    FilterChip(selected = asr == 1, onClick = { asr = 1; s.asr = 1; PrayerReminders.scheduleAll(this@PrayerActivity) }, label = { Text(tr("Shafi","शाफ़ई","Shafi")) })
                }
                Text(tr("Remind me before","कितना पहले याद दिलाएँ","Reminder kitna pehle"), style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to tr("On time","समय पर","Waqt pe"), 5 to tr("5 min","5 मिनट","5 min"), 10 to tr("10 min","10 मिनट","10 min")).forEach { (m, l) ->
                        FilterChip(selected = lead == m, onClick = { lead = m; s.prayerLead = m; PrayerReminders.scheduleAll(this@PrayerActivity) }, label = { Text(l) })
                    }
                }
                Text(tr("Times are calculated and may differ by 1-3 minutes from your mosque's timetable. Ask your mosque for jamaat times.","ये समय हिसाब से निकाले गए हैं और आपकी मस्जिद के समय से 1-3 मिनट अलग हो सकते हैं। जमात का समय मस्जिद से ही पूछें।","Yeh waqt hisaab se nikalte hain, aapki masjid ke waqt se 1-3 minute alag ho sakte hain. Jamaat ka waqt masjid mein hi poochein."),
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
