package com.autosilentzone

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val label = intent.getStringExtra("label") ?: "Namaz"
        if (intent.getBooleanExtra("azan", false)) {
            val s = Store(ctx)
            if (s.activeZone != null) {
                // Masjid/silent zone ke andar azan nahi bajta, sirf notification
                PrayerReminders.notify(ctx, label, 0)
            } else if (s.azanOn) {
                try {
                    ContextCompat.startForegroundService(
                        ctx, Intent(ctx, AzanService::class.java)
                            .putExtra("label", label).putExtra("key", intent.getStringExtra("key") ?: "")
                    )
                } catch (_: Exception) { PrayerReminders.notify(ctx, label, 0) }
            }
        } else {
            PrayerReminders.notify(ctx, label, intent.getIntExtra("lead", 0))
        }
        PrayerReminders.scheduleAll(ctx)   // agle alarm laga do
    }
}

object PrayerReminders {
    private const val CH = "prayer"
    private val keys = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")

    private fun pi(ctx: Context, rc: Int, label: String = "", lead: Int = 0, azan: Boolean = false, key: String = ""): PendingIntent {
        val i = Intent(ctx, PrayerAlarmReceiver::class.java)
            .putExtra("label", label).putExtra("lead", lead).putExtra("azan", azan).putExtra("key", key)
        return PendingIntent.getBroadcast(ctx, rc, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Aaj aur kal ke chune hue waqton ke reminder aur azan ke alarm dobara lagata hai. */
    fun scheduleAll(ctx: Context) {
        val s = Store(ctx)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (rc in 0 until 20) am.cancel(pi(ctx, rc))
        if (!s.hasLocation || s.prayerOn.isEmpty()) return
        val now = System.currentTimeMillis()
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        val azan = s.azanOn && (AzanService.fileFor(ctx, "dhuhr") != null || AzanService.fileFor(ctx, "fajr") != null)

        fun set(at: Long, op: PendingIntent) {
            try {
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
            } catch (_: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
            }
        }

        for (off in 0..1) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, off) }
            PrayerTimes.compute(cal, s.lat, s.lng, s.method, s.asr).forEach { p ->
                val idx = keys.indexOf(p.key)
                if (idx < 0 || p.key !in s.prayerOn || p.time < 0) return@forEach
                val at = p.time - s.prayerLead * 60_000L
                // Azan bajna hai aur reminder "waqt pe" hai to double notification nahi
                if (at > now && !(azan && s.prayerLead == 0)) set(at, pi(ctx, off * 5 + idx, p.label, s.prayerLead))
                if (azan && p.time > now) set(p.time, pi(ctx, 10 + off * 5 + idx, p.label, 0, true, p.key))
            }
        }
    }

    fun notify(ctx: Context, label: String, lead: Int) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Namaz reminder", NotificationManager.IMPORTANCE_HIGH))
        val text = if (lead > 0) "$label ka waqt $lead minute mein" else "$label ka waqt ho gaya"
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(label).setContentText(text).setAutoCancel(true).build()
        try { nm.notify(label.hashCode(), n) } catch (_: SecurityException) {}
    }
}
